import React from 'react';
import { ExternalLink, Info } from 'lucide-react';
import { AdSenseConfig } from '../types';

interface AdSenseUnitProps {
  format: 'leaderboard' | 'in-article' | 'sidebar' | 'in-feed' | 'sticky-bottom';
  config?: AdSenseConfig;
  className?: string;
}

export const AdSenseUnit: React.FC<AdSenseUnitProps> = ({ format, config, className = '' }) => {
  // If explicitly disabled in settings
  if (config && !config.enabled) {
    return null;
  }

  // Realistic converting high-intent advertiser offers (to maximize RPM and CTR compliance)
  const sampleOffers = {
    leaderboard: {
      headline: 'Home Depot Pro Tool Event: Up to 40% Off Select Cordless Bare Tools & Kits',
      subtext: 'Free 2-day delivery on select cordless hammer drills, impact drivers & combo kits.',
      cta: 'Shop Pro Event Deals',
      url: 'https://homedepot.com',
      advertiser: 'The Home Depot Pro'
    },
    'in-article': {
      headline: 'Amazon Spring Hardware Deals: Flash Discounts on Top-Rated Workstation Gear',
      subtext: 'Prime members receive free same-day shipping on select drills, robot vacuums & kitchen appliances.',
      cta: 'Claim Limited Deal',
      url: 'https://amazon.com',
      advertiser: 'Amazon Verified Merchant'
    },
    sidebar: {
      headline: 'Best Buy Tech Clearance: Save Up to $250 on Flagship Noise-Canceling Audio',
      subtext: 'Shop price drops on Sony, Bose, and premium noise-cancelling headphones while inventory lasts.',
      cta: 'View Clearance Prices',
      url: 'https://bestbuy.com',
      advertiser: 'Best Buy Official'
    },
    'in-feed': {
      headline: 'Sponsored: Compare Verified Home Backup Generators & Save $500 Today',
      subtext: 'Get instant pre-season rebates on portable LiFePO4 emergency solar generators and power stations.',
      cta: 'Explore Energy Deals',
      url: 'https://ecoflow.com',
      advertiser: 'Clean Energy Partners'
    },
    'sticky-bottom': {
      headline: 'Exclusive Home Appliance Flash Sale: Extra 15% Off with Coupon at Checkout',
      subtext: 'Special pricing on espresso machines, dual-zone air fryers and robot vacuums.',
      cta: 'Check Instant Promo',
      url: 'https://amazon.com',
      advertiser: 'Verified Consumer Brands'
    }
  };

  const offer = sampleOffers[format];

  // LEADERBOARD BANNER (728x90 desktop / 320x50 mobile)
  if (format === 'leaderboard') {
    return (
      <div className={`w-full my-6 flex flex-col items-center ${className}`}>
        <div className="w-full max-w-4xl bg-stone-100/90 border border-stone-200/80 rounded-lg p-2.5 sm:px-6 sm:py-3.5 shadow-xs transition hover:border-amber-400/50">
          <div className="flex items-center justify-between text-[10px] font-mono text-stone-600 uppercase tracking-widest mb-1.5 px-0.5">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
              Sponsored Advertisement
            </span>
            <span className="flex items-center gap-1 hover:text-stone-600 cursor-pointer">
              <span>AdChoices</span>
              <Info className="w-3 h-3 text-stone-600" />
            </span>
          </div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3 rounded border border-stone-200/60">
            <div className="flex-1">
              <p className="text-xs font-semibold uppercase text-amber-700 tracking-wider mb-0.5">
                {offer.advertiser}
              </p>
              <h4 className="text-sm sm:text-base font-bold text-stone-900 leading-snug">
                {offer.headline}
              </h4>
              <p className="text-xs text-stone-600 line-clamp-1 mt-0.5">
                {offer.subtext}
              </p>
            </div>
            <a
              href={offer.url}
              target="_blank"
              rel="noopener noreferrer sponsored"
              className="inline-flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs sm:text-sm px-4 py-2 rounded-md transition shadow-xs whitespace-nowrap active:scale-98"
            >
              <span>{offer.cta}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    );
  }

  // IN-ARTICLE NATIVE DISPLAY BANNER
  if (format === 'in-article') {
    return (
      <div className={`my-8 p-4 bg-linear-to-br from-amber-50/50 via-stone-50 to-stone-100 border border-amber-200/70 rounded-xl shadow-xs ${className}`}>
        <div className="flex items-center justify-between text-[10px] font-mono text-stone-600 uppercase tracking-wider mb-2">
          <span>Google AdSense • Verified Partner Offer</span>
          <span className="flex items-center gap-1">
            <span>AdChoices</span>
            <Info className="w-2.5 h-2.5" />
          </span>
        </div>
        <div className="p-4 bg-white rounded-lg border border-stone-200/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="inline-block bg-amber-100 text-amber-900 text-[11px] font-bold px-2 py-0.5 rounded">
              Special Consumer Offer
            </span>
            <h4 className="text-base sm:text-lg font-bold text-stone-900">
              {offer.headline}
            </h4>
            <p className="text-xs sm:text-sm text-stone-600">
              {offer.subtext}
            </p>
          </div>
          <a
            href={offer.url}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="w-full md:w-auto text-center inline-flex items-center justify-center gap-2 bg-stone-900 hover:bg-amber-500 hover:text-stone-950 text-white font-bold text-sm px-5 py-2.5 rounded-lg transition shadow-xs whitespace-nowrap"
          >
            <span>{offer.cta}</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    );
  }

  // SIDEBAR SKYSCRAPER (300x600 or 300x250)
  if (format === 'sidebar') {
    return (
      <div className={`bg-stone-50 border border-stone-200/90 rounded-xl p-3 shadow-xs ${className}`}>
        <div className="flex items-center justify-between text-[10px] font-mono text-stone-600 uppercase mb-2">
          <span>Advertisement</span>
          <span>AdChoices</span>
        </div>
        <div className="bg-white p-4 rounded-lg border border-stone-200/80 flex flex-col items-center text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 font-bold text-lg">
            %
          </div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700">
            {offer.advertiser}
          </span>
          <h4 className="text-sm font-bold text-stone-900 leading-snug">
            {offer.headline}
          </h4>
          <p className="text-xs text-stone-600">
            {offer.subtext}
          </p>
          <a
            href={offer.url}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="w-full bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs py-2.5 px-3 rounded-md transition shadow-xs inline-flex items-center justify-center gap-1.5"
          >
            <span>{offer.cta}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    );
  }

  // IN-FEED CARD (Native style between review cards)
  if (format === 'in-feed') {
    return (
      <div className={`bg-linear-to-r from-amber-500/10 via-stone-50 to-stone-100 border border-amber-300/60 rounded-xl p-5 shadow-xs transition hover:border-amber-400 ${className}`}>
        <div className="flex items-center justify-between text-[10px] font-mono text-amber-800 uppercase tracking-widest mb-2">
          <span className="font-bold bg-amber-200/80 px-1.5 py-0.5 rounded">Promoted Recommendation</span>
          <span>Google AdSense Native</span>
        </div>
        <h4 className="text-base sm:text-lg font-bold text-stone-900 mb-1">
          {offer.headline}
        </h4>
        <p className="text-xs sm:text-sm text-stone-600 mb-3">
          {offer.subtext}
        </p>
        <div className="flex items-center justify-between pt-2 border-t border-amber-200/50">
          <span className="text-xs text-stone-600">{offer.advertiser}</span>
          <a
            href={offer.url}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="inline-flex items-center gap-1 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs px-3 py-1.5 rounded transition"
          >
            <span>{offer.cta}</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    );
  }

  // STICKY BOTTOM ANCHOR
  return (
    <div className={`fixed bottom-0 left-0 right-0 z-40 bg-stone-900/95 backdrop-blur-md border-t border-amber-500/40 px-4 py-2.5 shadow-2xl text-white ${className}`}>
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3 text-xs sm:text-sm">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="bg-amber-500 text-stone-950 text-[10px] font-bold px-1.5 py-0.5 rounded uppercase shrink-0">
            Ad
          </span>
          <p className="font-medium truncate">
            {offer.headline}
          </p>
        </div>
        <a
          href={offer.url}
          target="_blank"
          rel="noopener noreferrer sponsored"
          className="shrink-0 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold px-3 py-1 rounded text-xs transition"
        >
          {offer.cta}
        </a>
      </div>
    </div>
  );
};
